# Copyright 2018 Databricks, Inc.


VERSION = '0.8.2.dev0'
