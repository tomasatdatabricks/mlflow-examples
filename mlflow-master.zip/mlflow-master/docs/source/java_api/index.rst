.. _java_api:

Java API
==========

This file is a placeholder. Javadoc is filled in by the build-javadoc.sh script, executed during "make html".
